var flag=0;
function isDateValid(toCheckDate)
{
	 	var Date_array=toCheckDate.split('/');
	    var d=Date_array[0];
		var m=Date_array[1];
		var y=Date_array[2];
		var months = [31,28,31,30,31,30,31,31,30,31,30,31];
		if(!(d>0 && m>0 && y>0 && m<=12 && (d<=months[m-1] || (m==2 && d==29 && ((y%4==0&& y%100!=0) || (y%400==0)))) )){
			return false;
		}  
		else {
			return true;
		}
}

$(document).ready(function() {
	
	alert("hi");
	$("#SanctionNo").numberLettersAndSpaceAndBackspace();
	$("#VoucherNo").numberLettersAndSpaceAndBackspace();
	$("#PayOrderNo").numberLettersAndSpaceAndBackspace();
	$("#AllocationId").numbers();
	$("#Amount").decimal();
	$("#KmPower").decimal();
	$("#Detailsofpay").numberLettersAndSpaceAndBackspace();
	
 
	$('#SanctionDate1').datepicker({
	   	 dateFormat: 'dd/mm/yy',
	   	showOn: 'both',
	     buttonImage: 'images/calendar.gif',
	     buttonImageOnly: true,
	   	changeYear : true,
   	changeMonth : true,
	   	 maxDate : new Date()
   });
	
	$('#VoucherDate1').datepicker({
   	 dateFormat: 'dd/mm/yy',
   	 showOn: 'both',
        buttonImage: 'images/calendar.gif',
        buttonImageOnly: true,
   	changeYear : true,
   	changeMonth : true,
   	 maxDate : new Date()
   });
	
	$('#toDateVal').datepicker({
	   	 dateFormat: 'dd/mm/yy',
	   	 showOn: 'both',
	        buttonImage: 'images/calendar.gif',
	        buttonImageOnly: true,
	   	changeYear : true,
	   	changeMonth : true,
	   	 maxDate : new Date()
	   });
	
	$('#frmDateVal').datepicker({
	   	 dateFormat: 'dd/mm/yy',
	   	 showOn: 'both',
	        buttonImage: 'images/calendar.gif',
	        buttonImageOnly: true,
	   	changeYear : true,
	   	changeMonth : true,
	   	 maxDate : new Date()
	   });
	
	$('#PayOrderDate1').datepicker({
  	 dateFormat: 'dd/mm/yy',
  	showOn: 'both',
   buttonImage: 'images/calendar.gif',
   buttonImageOnly: true,
  	changeYear : true,
	changeMonth : true,
	 maxDate : new Date()
  });
	
	
	
	/* $('#PeriodClaimFrm1').datepicker({
	   	 dateFormat: 'dd/mm/yy',
	   	showOn: 'both',
	    buttonImage: 'images/calendar.gif',
	    buttonImageOnly: true,
	   	changeYear : true,
		changeMonth : true,
		maxDate : new Date()
	   });
	
	$('#PeriodClaimTo').datepicker({
	   	 dateFormat: 'dd/mm/yy',
	   	showOn: 'both',
	    buttonImage: 'images/calendar.gif',
	    buttonImageOnly: true,
	   	changeYear : true,
		changeMonth : true,
		maxDate : new Date()
	   }); */
	
	 
	 var delSettings ={
			  // define settings for Delete 
			  mtype: "post",	  
			  onclickSubmit: function (rp_ge, rowid) {		         
			             rp_ge.url = "deletetempPower.action?TempPowerId="+rowid;
			             $("#tempPowerList").trigger("reloadGrid");
			  }
		  };
	 $("#tempPowerList").jqGrid({
	    	datatype:'xml',
			url:"getTempPowerDetails.action?action=fetchData",	  	   
			colNames:['Sanction No','Sanction Date','Voucher No','Voucher Date','Bill No','Pay Order Date','Details Of Pay','Allocation','Project','Project','Executive','Executive','Amount','Km @','Period Of Claim From','Claim To','Opening Meter','Closing Meter'],
			colModel:[
	          	{ name: 'SanctionNo', index: 'SanctionNo',width : 108, align:'left',editable:true} ,
	   			{ name: 'SanctionDate',index: 'SanctionDate',width : 120 ,formatter:'date',editable:true},
	    		{ name: 'VoucherNo', index: 'VoucherNo',width : 103 ,align: 'left',editable:true} ,
	    		{ name: 'VoucherDate',index: 'VoucherDate',width : 120 ,formatter:'date',editable:true},
	    		{ name: 'BillNo',index: 'BillNo',width : 120 ,align:'left',editable:true},
	    		{ name: 'PayOrderDate',index: 'PayOrderDate',width : 134,formatter:'date',editable:true},
	    		{ name: 'DetailsOfPay', index: 'DetailsOfPay',width : 100 ,align: 'left',editable:true} ,
	    		{ name: 'Allocation', index: 'Allocation',width : 100 ,align: 'left',editable:true} ,
	    		{ name: 'Project', index: 'Project',width :180,align: 'left',editable:false} ,
	    		{ name: 'ProjectID', index: 'ProjectID',width :-20 ,align: 'left',editable:true ,edittype:'select', editoptions:{dataUrl:'getProjectlist1.action'}} ,
	    		{ name: 'Executive', index: 'Executive',width :180,align: 'left',editable:false} ,
	    		{ name: 'ExecutiveID', index: 'ExecutiveID',width :-20 ,align: 'left',editable:true ,edittype:'select', editoptions:{dataUrl:'getProjectlist1.action'}} ,
	    		{ name: 'Amount', index: 'Amount',width : 100 ,align: 'left',editable:true} ,
	    		{ name: 'Km', index: 'Km',width : 100 ,align: 'left',editable:true} , 
	    		{ name: 'PeriodClaimFrm', index: 'PeriodClaimFrm',formatter:'date',width : 100 ,align: 'left',editable:true} ,
	    		{ name: 'PeriodClaimTo', index: 'PeriodClaimTo',formatter:'date',width : 100 ,align: 'left',editable:true} ,
	    		{ name: 'OpeningMtr', index: 'OpeningMtr',width : 100 ,align: 'left',editable:true} ,
	    		{ name: 'ClosingMtr', index: 'ClosingMtr',width : 100 ,align: 'left',editable:true} , 
	    		
	 		 ],
	 	   rowNum:10,
		   loadonce:true,
		   rownumbers:true,
	 	   rowList:[5,10,20],
		   cellEdit: false, 
		   viewrecords:true,
		   caption:'Temp Power Connection',		   
		   pager: '#pager',
		   width:callSmallGridWidth(),
		   height: 100,
		   shrinkToFit:false,
		   closeAfterAdd:true,
	       closeAfterEdit:true,
	       reloadAfterSubmit:true,
		   cellsubmit: 'clientArray',
		   ondblClickRow: function(rowid, ri, ci) {
		        var p = grid[0].p;
		        if (p.selrow !== rowid) {
		            // prevent the row from be unselected on double-click
		            // the implementation is for "multiselect:false" which we use,
		            // but one can easy modify the code for "multiselect:true"
		            grid.jqGrid('setSelection', rowid);
		        }					       
		        grid.jqGrid('editGridRow', rowid, editSettings);
		    }
		   //editurl: editSettings
		    
		 });
		
	 	jQuery("#tempPowerList").navGrid('#pager',{ edit:false,add:false,del:true,search:true},{},{},delSettings,{closeAfterSearch:true})
	 	.navButtonAdd('#pager',{ caption:"Edit", buttonicon:"ui-icon-pencil",position:"first",title:'Edit',
		 	onClickButton:function(){
		 		flag=1;	
		 	
		 		
		 		
	        	var rowid = $("#tempPowerList").jqGrid('getGridParam', 'selrow');	        	
	        	if(rowid==null){
	        		alert("Please select Row.");
	        		return;
		        }
	        	var gridRow = $("#tempPowerList").getRowData(rowid);
	        	//alert("flag in edit ="+flag)
	        	$("#rowIdVal").val(rowid);
	        	
	        	$("#SanctionNo").val(gridRow.SanctionNo);
	    		$("#SanctionDate1").val(gridRow.SanctionDate);
	    		$("#VoucherNo").val(gridRow.VoucherNo);
	    		$("#VoucherDate1").val(gridRow.VoucherDate);
	    		$("#BillNo").val(gridRow.BillNo);
	    		$("#PayOrderDate1").val(gridRow.PayOrderDate);
	    		$("#Detailsofpay").val(gridRow.DetailsOfPay);
	    		$("#AllocationId").val(gridRow.Allocation);
	    		$("#projectID").val(gridRow.ProjectID);
	    		$("#ExecutiveID").val(gridRow.ExecutiveID);
	    		$("#Amount").val(gridRow.Amount);
	    		$("#KmPower").val(gridRow.Km);
	    		$("#frmDateVal").val(gridRow.PeriodClaimFrm);
	    		$("#toDateVal").val(gridRow.PeriodClaimTo);
	    		$("#OpeningMtr").val(gridRow.OpeningMtr);
	    		$("#ClosingMtr").val(gridRow.ClosingMtr);
	    	     
	    		loadprojects();
	    		
		 	}
	 	});

	 	  $('#projectID').change(loadprojects);
	 	    
	  	 function loadprojects() {
	  				  					$("select#ExecutiveID option").remove();
	  				  					$.post('executiveCode.action?projid='+$("#projectID").val(),function(data){
	  				  					var sel=$('#ExecutiveID');
	  				  					//alert(data.Executives.length);
	  				  					$('<option>').text('-Select Executive -').val('0').appendTo(sel);
	  				  					if(data.Executives.length==0)
	  				  					{
	  				  						alert("No Executive Found for this Project");
	  				  					}
	  				  					for (var i = 0; i < data.Executives.length; i++)
	  				  					{
	  				  						//alert(data.Executives[0].strDesc);
	  				  						$('<option>').text(data.Executives[i].strDesc).val(data.Executives[i].iGecid).appendTo(sel);
	 				
	  				  					}},'json');
	  		 
	  							}
	  	
	  	
	  	
	 });

function onsaveBut(){
	
	 if(flag==1){ 
		 //In Update Mode 
		 $.post('edittempPower.action?id='+$("#rowIdVal").val()+'&SanctionNo='+$("#SanctionNo").val()+'&SanctionDate1='+$("#SanctionDate1").val()
					+'&VoucherNo='+$("#VoucherNo").val()
			  		+'&VoucherDate1='+$("#VoucherDate1").val()
					 +'&BillNo='+$("#BillNo").val()
					 +'&PayOrderDate1='+$("#PayOrderDate1").val() 
					  +'&toDateVal='+$("#toDateVal").val() 
					  +'&frmDateVal='+$("#frmDateVal").val() 
						+'&Detailsofpay='+$("#Detailsofpay").val()
						+'&AllocationId='+$("#AllocationId").val()
						+'&Project='+$("#projectID option:selected").val()
						+'&Executive='+
				 $("#ExecutiveID option:selected").val()+'&Amount='+$("#Amount").val()
				 +'&Km='+$("#KmPower").val()
					+'&OpeningMtr='+$("#OpeningMtr").val()
					 +'&ClosingMtr='+$("#ClosingMtr").val(),
						
						function(data){
					document.getElementById("succMsg").innerHTML = data.status;
					alert(data.status);
					loadonce : false,
					location.reload();
					document.getElementById('submitForm').reset();
					
				},"json");
		 $("#tempPowerList").trigger("reloadGrid");
			$("#messagebox").show();
			
		 
		 flag = 0;
		 return false;
	}
	 
	var claimt=$("#toDateVal").val();
	var claimf=$("#frmDateVal").val();
	
	$.post('temppowercon1.action?SanctionNo='+$("#SanctionNo").val()+
			'&SanctionDate1='+$("#SanctionDate1").val()
			+'&VoucherNo='+$("#VoucherNo").val()
	  		+'&VoucherDate1='+$("#VoucherDate1").val()
			 +'&BillNo='+$("#BillNo").val()
			 +'&PayOrderDate1='+$("#PayOrderDate1").val() 
			  +'&toDateVal='+$("#toDateVal").val() 
			  +'&frmDateVal='+$("#frmDateVal").val() 
				+'&Detailsofpay='+$("#Detailsofpay").val()
				+'&AllocationId='+$("#AllocationId").val()
				+'&Project='+$("#projectID option:selected").val()
				+'&Executive='+
		 $("#ExecutiveID option:selected").val()+'&Amount='+$("#Amount").val()
		 +'&Km='+$("#KmPower").val()
			+'&OpeningMtr='+$("#OpeningMtr").val()
			 +'&ClosingMtr='+$("#ClosingMtr").val(),
			
					function(data){
				document.getElementById("succMsg").innerHTML = data.status;
				alert(data.status);
				loadonce : false,
				location.reload();
				document.getElementById('submitForm').reset();
				
			},"json");
	$("#tempPowerList").trigger("reloadGrid");
		$("#messagebox").show();
			  
}

function close(){
	$("#messagebox").hide();
}