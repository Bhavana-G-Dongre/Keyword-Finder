/*
 * Common functions used in Agreement.jsp and AgreementEdit.jsp  
 */




function addDEstimate()
{
		$('#commdate').datepicker("option","dateFormat","dd/mm/yy");		//optional
		var newdate	=	$('#commdate').val();
		
		var start 	= $.datepicker.parseDate('dd/mm/yy', newdate);
		var dmyr 	= $('#dmyear').val();
	    var t 		= $('#dmyvalue').val();
	    var d, m, y ;
	    var months 	= new Array(31,28,31,30,31,30,31,31,30,31,30,31);
		var edate 	= new Date(start);
		
		d 	= edate.getDate();
		m	= edate.getMonth();
		//alert("m = "+m);
		y 	= edate.getFullYear();
		m = m+1;
		
		if(t == "" || t == " ")
		{
			t = 0;
		}
		t 	= parseInt(t);
		
		switch(dmyr)
	    {
		//alert("test");
	    	case 'D':
	    			 if(t > (months[m-1] - d))
	    			 {	
	    			 	d = t - (months[m-1] - d);
	    			 	m++;
	    				do
	    				{
	    					
	    					if(m > 12)
	    					{
	    						m = 1;
	    						y++;
	    						if((y % 4 == 0) || ((y % 400 == 0) && (y % 100!= 0)))
	    						{
	    							months[1] = 29;			
	    						}
	    						else
	    						{
	    							months[1] = 28;			
	    						}
	    						m++;
	    						
	    					}
	    					if(d > months[m-1] )
	    					{
	    						d = d - months[m-1];
	    						
	    					}else {
	    						
	    					}
	    					//m++;
	    				}while(parseInt(d/ months[m-1]) != 0);
	    			 }
	    			 else
	    			 {	 
	    			 	d = d + parseInt(t);
	    			 }
	    			 break;
	    	case 'M':
	    			 var tm = m + parseInt(t); 
	    			 if(tm > 12)
	  				 {	  	
	    			 	if(parseInt(t) < 12)
	    			 	{
	    			 		y = y + parseInt(tm/12);
	    			 		m = tm%12;
	    			 	} 	
	    			 	else
	    			 	{
	    			 		y = y + parseInt(parseInt(t)/12);
	    			 	
	    			 		m = m + (parseInt(t)%12);
	    			 		if(m > 12)
	    			 		{
	    			 			m = 0;
	    			 			m = m + (parseInt(t)%12);
	    			 		}
	    			 	}
	    			 }
					else
					{ 	 m = tm;
					}		
   				 	 break;
	    	case 'Y':
	    			 y = y + parseInt(t);
				 	 break;
	    }
	//alert("d= "+d+" m "+m);
		edate = d+'/'+ m +'/'+y; 
		$('#wrkcmpldt').val(edate);
}


/*
 *  Common Date functions 
 */

function setcomdate()
{
	$("#commdate").datepicker("destroy");
	$('#commdate').val('');

	var extractDate =	$('#loadate').val();
	if(extractDate == "")
		showdmy(1);
	else
	{
		var cc			=	extractDate.split("/");
		var properDate 	=	(cc[0]+ '/'  + cc[1] + '/' +cc[2]);
		var cfDate 		=	$.datepicker.parseDate('dd/mm/yy', properDate);
		var date1 		= 	new Date(cfDate); 
		
		$('#commdate').datepicker({
			dateFormat	: 'dd/mm/yy',
			changeMonth	: true,
			changeYear	: true,
			minDate		: new Date(date1)
		});
		
		$('#commdate').datepicker({ dateFormat: 'dd/mm/yy' });
		$('#commdate').val(properDate);
		
	}
}

function showdmy(flag)
{		
	
	if($('#loadate').val() == "") 
	{
		alert("Please enter the LOA Date ");
		$('#loadate').focus();
	}
	else if( ( $('#commdate').val() == "") && (flag == 0)) 
	{
		alert("Please enter the Work Commencement Date");
		$('#commdate').focus();
	}
	else
	{
		if($("#dmyear").val() != -1)
		{
			$("#dmyvalue").show();
			if($("#dmyvalue").val()!=""){
				addDEstimate();
			}
			
		}
		else
		{
			$("#dmyvalue").hide();
		}
	}
} 

function checkdtpicker()
{
	showdmy('1');
//	alert($('#loadate').val()+ " LoA ");
	setcomdate();
}


/* Grid and AJAX based calls */
function callAutoHeight(){
	
}
function callW(){
	var finalWidth = null;
	if(navigator.appName == "Microsoft Internet Explorer"){
		var width = document.documentElement.offsetWidth;
		finalWidth = width*66/100;
	}else {
		var width = window.innerWidth;
		finalWidth = width*66/100;
	}
	return finalWidth;
}

function callSmallGridWidth(){
	
	var finalSmallWidth= null;
	if(navigator.appName == "Microsoft Internet Explorer"){
		var smallWidth = document.documentElement.offsetWidth;
		finalSmallWidth = smallWidth*70/100;
	} else {
		var smallWidth = window.innerWidth;
		finalSmallWidth = smallWidth*70/100;
	}
	
	return finalSmallWidth;
}

function callSmallGridWidth1(){
	
	var finalSmallWidth= null;
	if(navigator.appName == "Microsoft Internet Explorer"){
		var smallWidth = document.documentElement.offsetWidth;
		finalSmallWidth = smallWidth*80/100;
	} else {
		var smallWidth = window.innerWidth;
		finalSmallWidth = smallWidth*80/100;
	}
	
	return finalSmallWidth;
}
function returnHeight(){
	
	var finalHeight = null;
	if(navigator.appName == "Microsoft Internet Explorer"){
		var height = document.documentElement.offsetHeight;
		finalHeight = height-135;
	}else {
		var height = window.innerHeight;
		finalHeight = height-159;
	}
	
	return finalHeight;
}

$(function() 
{
	$('.sub-table tr').addClass('table-row-light-blue');
}); 

function close(a)
{
	$("#message"+a).empty();
}

function secgrid()
{
	$("#seconddiv").append('<table id=\"list\" padding="5px"></table><div id=\"pager\"></div>');
	$("#seconddiv").append( '<table class=\"main-table\"><tr id=\"ui-widget-header\"><td align=\"right\" >'+
						'Schedule Total:&nbsp;&nbsp;&nbsp;&nbsp;'+
						'<input type="text" name="tamount" id="total" Style="text-align: right;background-color:'+
						' #ccc;" readonly="true" value="0.0" /></td></tr></table>');
	var grid1="#"+"list";
	$(grid1).jqGrid({	
  	datatype:'local',
	colNames:['Schedule','Par Amount','Percentage','Discount','Effective Amount'],
	colModel:[
				{ name: 'SCHEDULE', index: 'SCHEDULE',align: 'left'} ,
				{ name: 'VALUE', index: 'VALUE',  template: numberTemplate} ,
				{ name: 'PERCENTAGE',index: 'PERCENTAGE',align:'right',editable:true,formatter:'number',formatoptions:{decimalPlaces: 2} },
				{ name: 'DISCOUNT',index: 'DISCOUNT',align:'right',editable:true,formatter:'number',formatoptions:{decimalPlaces: 2}},
				{ name: 'TOTAL', index: 'TOTAL',template: numberTemplate} 
			 ],
	rownumbers:	true,
	cellEdit: 	true, 
	viewrecords:true,
	caption:	'Agreement Schedule-wise Details',
	width:		callSmallGridWidth1(),
	height:		'auto',
	cellsubmit: 'clientArray',
	onSelectRow: function(id){
			
		if(id && id!==lastsel){
					$(grid1).jqGrid('saveRow',lastsel);
					lastsel=id; 
			}
		},

	ondblClickRow: 	function(id)
				  	{
		   					if(id && id!==lastsel)
    					{
    						$(grid1).jqGrid('editRow',id,true); 
    						lastsel=id; 
    					}
				  	},
	
	beforeEditCell:function(rowid, cellname, value, iRow, iCol)
					{
						lastsel=rowid;
					},
	afterSaveCell : function(rowid,name,val,iRow,iCol) 
					{ 
						//var val1 = $(grid1).jqGrid('getCell',rowid,iCol-1);
						var percent = $(grid1).getCell(rowid,'PERCENTAGE');
						var discount = $(grid1).getCell(rowid,'DISCOUNT');
						var total = $(grid1).getCell(rowid,'VALUE');
						total = (parseFloat(total)+parseFloat(total*(percent/100)))-parseFloat(total*(discount/100));
						$(grid1).jqGrid('setRowData',rowid,{TOTAL:total.toFixed(2)});
						gettottal();
						setRecoveryAmount();
						
					}
					});
}



function gettottal()
{
	var gridName1			=	"list";
	var grid1				=	$("#"+gridName1);
	var NumberOfRecord11	=	grid1.jqGrid('getGridParam','records');
	var s11	=	new Array();
	s11 	= 	grid1.jqGrid('getDataIDs');
	var tot	=	0.0;
	for(var t = 0;t < NumberOfRecord11; t++)
	{
		var get =	grid1.jqGrid('getRowData',s11[t]);
		tot		=	tot+parseFloat(get.TOTAL);
	}
	$("#total").val(tot.toFixed(2));
	calcAgtTotal();
	$('#buttonAdd').removeAttr('disabled');
	$("#bottonDiv").show();
}

function  calcAgtTotal()
{
	var AgtTotalAmt 	= 0.0;
	var iDiscount 		= 0.0; 
	var FinalAgtTotal 	= 0.0;
	var scheduleTotal 	= 0.0;
	scheduleTotal		= parseFloat($('#total').val());
	
	if($("#discountper").val()!= '' || $("#discountper").val() == null ){
		iDiscount	= parseFloat($("#discountper").val());
	}
	AgtTotalAmt		= scheduleTotal*(iDiscount/100);
	FinalAgtTotal 	= scheduleTotal - AgtTotalAmt;
	$("#agtval").val(FinalAgtTotal.toFixed(2));
}

function rdrval()
{
	var tot = $("#total").val();
	$("#agtval").val(tot.toFixed(2));
}
function postRequest1(strURL) 
{

	var xmlHttp = null;
	if (window.XMLHttpRequest) 
	{ // Mozilla, Safari, ...
		xmlHttp = new XMLHttpRequest();
	} 
	else if (window.ActiveXObject) 
	{ // IE
		xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
	}

	xmlHttp.open('POST', strURL, true);
	xmlHttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	xmlHttp.onreadystatechange = function() 
	{
		if (xmlHttp.readyState == 4) 
		{
			functionUpdate1(xmlHttp.responseText);
		}
	};
	xmlHttp.send(strURL);
}

function  functionUpdate1(data)
{
	/*$("#sType"+ch).attr('disabled',true);*/
}

function postRequest(strURL) 
{
	var xmlHttp = null;
	if (window.XMLHttpRequest) 
	{ // Mozilla, Safari, ...
		 xmlHttp = new XMLHttpRequest();
	} 
	else if (window.ActiveXObject) 
	{ // IE
		 xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
	}

	xmlHttp.open('POST', strURL, true);

	xmlHttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	xmlHttp.onreadystatechange = function() 
	{
		if (xmlHttp.readyState == 4) 
		{		
			functionUpdate(xmlHttp.responseText);
		}
	};
		xmlHttp.send(strURL);
}


/*
* @author : Prakash.M
* 
*/

function callIncrement(i,value){						
	var incrementValue = $("#increment").val();
	var riderValue	   = $("#agtval").val();		
	var url="<%=request.getContextPath()%>/callIncrementDiscount.action?type=i&idValue="+incrementValue+"&riderValue="+riderValue;
	postIncrementDiscount(url);			
}

function callDiscount(){			
	var riderValue = $("#agtval").val();
	var discountValue = $("#discount").val();
	var url='<%=request.getContextPath()%>/callIncrementDiscount.action?type=d&idValue='+discountValue+'&riderValue='+riderValue;
	postIncrementDiscount(url);
}

function postIncrementDiscount(strURL) 
{
	var xmlHttp = null;
	if (window.XMLHttpRequest) 
	{ // Mozilla, Safari, ...
		xmlHttp = new XMLHttpRequest();
	} 
	else if (window.ActiveXObject) 
	{ // IE
		xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
	}

	xmlHttp.open('POST', strURL, true);

	xmlHttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	xmlHttp.onreadystatechange = function() 
	{
		if (xmlHttp.readyState == 4) 
		{		
			updateIncrementDiscount(xmlHttp.responseText);
		}
	};
		xmlHttp.send(strURL);
}

function updateIncrementDiscount(response){
	var JSONObject = jQuery.parseJSON(response);			
	$("#agtval").val(JSONObject.riderValue.toFixed(2));
}

// select the first tab 
function activateTab(){
	var liFirstId = $("ul#uu li:first").attr("id");
	  showGrid(liFirstId);

}

function AddNewRecovery() 
{
	//alert("came");
	if($("#recoveryCode").val() == '--Select--' || $("#recoveryCode").val() == '-1')
	{
		alert("Please enter the Recovery Code");
		$("#recoveryCode").focus();
		return false;          
	}
	if($("#recoveryAmount").val()=='')
	{
		alert("Please enter the Recovery Amount");
		$("#recoveryCode").focus();
		return false;          
	}  
	
	var appendTxt = "<tr class='ui-widget-content jqgrow ui-row-ltr' id='"+$("#recoveryCode").val()+"'> <td align='left'>" +
					$("#recoveryCode").val()+ "</td><td align='right'>"+
					parseFloat($("#percentage").val()).toFixed(2)+"</td><td align='right'>"+ 
					parseFloat($("#recoveryAmount").val()).toFixed(2)+ 
					"</td><td align='center'><input type=\"button\" "+
					" class=\"button2a\" value = \"Delete\" /></td></tr>";

	$("#tbl tr:last").after(appendTxt);
	$("#tbl tr:last").hide().fadeIn('slow');
	
	$("#recoveryCode option:selected").remove();
	
	$("#recoveryCode").val('--Select--');
	$("#recoveryAmount").val("00.00");
	$("#percentage").val("00.00");
//	setRecoveryAmount();
}

function collectRecoverValue()
{
	var table 		= document.getElementById('tbl');
	var rows		= table.getElementsByTagName('tr'), i, j, cells;
	var recovery 	= new String();
	for (i = 0, j = rows.length; i < j; i++) 
	{
		cells = rows[i].getElementsByTagName('td');
		if (!cells.length) 
		{
			continue;
		}
		recoveryCode	= cells[0].innerHTML;
		recoveryPer		= cells[1].innerHTML;
		recoveryAmount 	= cells[2].innerHTML;
		recovery 		= recovery + recoveryCode + "#"+recoveryPer+"#" + recoveryAmount+ "&";
		
	}
	$('#recoveryString').val(recovery);
}

function checkBackSpace()
{
                  if(event.keyCode==8 || event.keyCode==13)
         {
               return false;
         }
}

function isDateValidate(toCheckDate)
{
	 	var Date_array=toCheckDate.split('/');
	    var d=Date_array[0];
		var m=Date_array[1];
		var y=Date_array[2];
		var months = [31,28,31,30,31,30,31,31,30,31,30,31];
		if(!(d>0 && m>0 && y>0 && m<=12 && (d<=months[m-1] || (m==2 && d==29 && ((y%4==0&& y%100!=0) || (y%400==0)))) )){
			alert("Enter valid Date.");
			return false;
		}  
		else {
			return true;
		}
}

function setRecoveryAmount(){
	
	var table 		= document.getElementById('tbl');
	var rows		= table.getElementsByTagName('tr'), i, j, cells;
	var zz 			= 0; 
	for (i = 0, j = rows.length; i < j; i++) 
	{
		cells = rows[i].getElementsByTagName('td');
		if (!cells.length) 
		{
			continue;
		}
			var modifiedAmtValue = 0;
			//var modifiedPerValue = 0;
			recoveryCode	= cells[0].innerHTML;
			recoveryPer		= cells[1].innerHTML;
			recoveryAmt		= cells[2].innerHTML;
			if(recoveryPer==""){
				//alert("test");
				recoveryPer=" ";
				//modifiedPerValue = recoveryAmt*100/$("#total").val();
				//cells[1].innerHTML = modifiedPerValue.toFixed(2);
			}else {
				modifiedAmtValue = $("#total").val()*recoveryPer/100;
				cells[2].innerHTML = modifiedAmtValue.toFixed(2);
			}
	}
}
function setRecoveryPercentage(){
		
		var table 		= document.getElementById('tbl');
		var rows		= table.getElementsByTagName('tr'), i, j, cells;
		var zz 			= 0; 
		for (i = 0, j = rows.length; i < j; i++) 
		{
			cells = rows[i].getElementsByTagName('td');
			if (!cells.length) 
			{
				continue;
			}
				var modifiedPerValue = 0;
				recoveryCode	= cells[0].innerHTML;
				recoveryPer		= cells[1].innerHTML;
				recoveryAmt		= cells[2].innerHTML;
				if(recoveryPer==""){
					//alert("test");
					modifiedPerValue = recoveryAmt*100/$("#total").val();
					cells[1].innerHTML = modifiedPerValue.toFixed(2);
				}
		}
}

function goBack(){
	window.history.back(-1);
	
}

function emdCashGrid()
{
	var codeTNumber	=$("#tenderno").val();
	var grid1="#"+"emdCashlist";
	$(grid1).jqGrid({	
		datatype:'xml',
 	  	mtype: 'Post', 		
		url:'getEmdCashList.action?tenderNo='+codeTNumber,
		colNames:['GR.No.','Cash Date','Amount','Place'],
		colModel:[
					{ name: 'GRNO', index: 'GRNO', 	align: 'left'} ,
					{ name: 'CashDate', index: 'CashDate', 	align: 'center'},
					{ name: 'Amount', index: 'Amount',  template: numberTemplate} ,
					{ name: 'Place', index: 'Place', 	align: 'left'} 

				 ],
		rownumbers:	true,
		cellEdit: 	true, 
		viewrecords:true,
		shrinkToFit:true,
		width:		callSmallGridWidth(),
		height:		'auto',
		cellsubmit: 'clientArray'
	});
}

function emdDDGrid()
{
	var codeTNumber	=$("#tenderno").val();
	var grid1="#"+"emdDDlist";
	$(grid1).jqGrid({	
		datatype:'xml',
 	  	mtype: 'Post', 		
		url:'getEmdDDList.action?tenderNo='+codeTNumber,
		colNames:['DD NO.','DD Date','Amount','Bank'],
		colModel:[
					{ name: 'DDNO', index: 'DDNO', 	align: 'left'} ,
					{ name: 'DD_DATE', index: 'DD_DATE', 	align: 'center',sorttype:'date',formatter:'date', datefmt: 'd/m/Y'} ,
					{ name: 'Amount', index: 'Amount',  template: numberTemplate} ,
					{ name: 'Bank', index: 'Bank', 	align: 'left'} 
				 ],
		rownumbers:	true,
		cellEdit: 	true, 
		viewrecords:true,
		shrinkToFit:true,
		width:		callSmallGridWidth(),
		height:		'auto',
		cellsubmit: 'clientArray'
	});
}

function emdFDRGrid()
{
	var codeTNumber	=$("#tenderno").val();
	var grid1="#"+"emdFDRlist";
	$(grid1).jqGrid({	
		datatype:'xml',
 	  	mtype: 'Post', 		
 	  	url:"getEmdFDRList.action?tenderNo="+codeTNumber,
		colNames:['FDR NO.','FDR Date','Amount','Bank'],
		colModel:[
					{ name: 'FDRNO', index: 'FDRNO', 	align: 'left'} ,
					{ name: 'FDRDate', index: 'FDRDate', align: 'center',sorttype:'date',formatter:'date', datefmt: 'd/m/Y'} ,
					{ name: 'Amount', index: 'Amount',  template: numberTemplate} ,
					{ name: 'Bank', index: 'Bank', 	align: 'left'} 
				 ],
		rownumbers:	true,
		cellEdit: 	true, 
		viewrecords:true,
		shrinkToFit:true,
		width:		callSmallGridWidth(),
		height:		'auto',
		cellsubmit: 'clientArray'
	});
}

