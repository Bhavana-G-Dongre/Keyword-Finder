var flag=0;

function isDateValid(toCheckDate)
{
	 	var Date_array=toCheckDate.split('/');
	    var d=Date_array[0];
		var m=Date_array[1];
		var y=Date_array[2];
		var months = [31,28,31,30,31,30,31,31,30,31,30,31];
		if(!(d>0 && m>0 && y>0 && m<=12 && (d<=months[m-1] || (m==2 && d==29 && ((y%4==0&& y%100!=0) || (y%400==0)))) )){
			return false;
		}  
		else {
			return true;
		}
}

function close(){
	$("#Successtable").hide();
	$("#Failedtable").hide();
		}


function validate1(){
	 var valu=$("#value").val();
	 var value=parseFloat(valu);
	 var Rpr=$("#valueOdRepairs").val();
	 var Rprval=parseFloat(Rpr);
	 if(Rprval>value)
	 	{
		 alert("Total Value of repairs cannot be more than vehicle value");	
		 return false;
	 	}
	
	 if($("#sanctionNo").val().length==0){
		 alert("Please enter the Sanction Number");
		 $("#sanctionNo").focus();
		 return false;
	 }
	 
	 if($("#vehicleId option:selected").val()=="-1"){
		 alert("Please select vehicle Number.");
		 $("#vehicleId").focus();
		 return false;
	 }	 
	
	 if($("#value").val().length==0){
		 alert("Please enter the Value");
		 $("#value").focus();
		 return false;
	 }
	 
	 if($("#controllingOfc").val().length==0){
		 alert("Please enter the Controlling office");
		 $("#controllingOfc").focus();
		 return false;
	 }
	 if($("#yearOfPurchase").val().length==0){
		 alert("Please enter the Year Of Purchase");
		 $("#yearOfPurchase").focus();
		 return false;
	 }
	 if($("#valueOdRepairs").val().length==0){
		 alert("Please enter the Value Of Repairs");
		 $("#valueOdRepairs").focus();
		 return false;
	 }
	 if($("#currBillAmt").val().length==0){
		 alert("Please enter the Current Bill Amount");
		 $("#currBillAmt").focus();
		 return false;
	 }

	 var dat1= $("#SanctionDate1").val();
	   if(!isDateValid(dat1)){
		  alert("Enter Valid Date");
		  $("#SanctionDate1").focus();
		  return false;
	     } 
	 
	 
	if(flag==1){ //In Update Mode
		$.post('editRepairvehi.action?id='+$("#rowIdVal").val()+'&sanctionNo='+$("#sanctionNo").val()+'&sanctionDate1='+$("#SanctionDate1").val()+'&vehicle='+$("#vehicleId option:selected").val()+'&value='+$("#value").val()+'&controllingOfc='+$("#controllingOfc").val()+'&yearOfPurchase='+$("#yearOfPurchase").val()+'&valueOdRepairs='+$("#valueOdRepairs").val()+'&currBillAmt='+$("#currBillAmt").val(),
				function(data){
			$("#Successtable").show();
			  if(data.message=="Updated"){
				  loadonce : false,
				  document.getElementById("message").innerHTML = 'Vehicle Repairs Updated Successfully  !!!!';
			  }else if(data.message=="Error"){
				  document.getElementById("message").innerHTML = 'Error';
			  }
			  
			  alert(data.message);
			  location.reload();
			  flag = 0;
		  },"json");
		 
		 
	     return false;
	}
	var abc=$("#SanctionDate1").val();
	$.post('saveReptoVeh.action?sanctionNo='+$("#sanctionNo").val()+'&SanctionDate1='+abc+'&vehicleId='+$("#vehicleId option:selected").val()+'&value='+$("#value").val()
			+'&controllingOfc='+$("#controllingOfc").val()+'&yearOfPurchase='+$("#yearOfPurchase").val()+'&valueOdRepairs='+$("#valueOdRepairs").val()+'&currBillAmt='+$("#currBillAmt").val(),
			function(data){
		 
		  if(data.message=="Saved"){
			 
				loadonce : false,
				
			  document.getElementById("message").innerHTML = 'Vehicle Repairs Updated Successfully  !!!!';
		  }else if(data.message=="Error"){
			  document.getElementById("message").innerHTML = 'Error';
		  }
		  $("#Successtable").show();
		  alert(data.message);
		  location.reload();
		  
		
		  
	  },"json");
	//return true;
	
}
function clearData(){
	$("#sanctionNo").val("");
	$("#value").val("");
	$("#controllingOfc").val("");
	$("#yearOfPurchase").val("");
	$("#valueOdRepairs").val("");
	$("#currBillAmt").val();
	$("#SanctionDate1").val("");
	$('#vehicleId option:first').attr('selected', 'selected');
}
/*$(document).ready(function(){

	//if(Message==0){$("#Successtable").show();}
	//$("#sanctionNo").numberLettersAndSpaceAndBackspace();
	$("#yearOfPurchase").numbers();
	$("#value").decimal();
	$("#valueOdRepairs").decimal();
	$("#currBillAmt").decimal();
	
	
	$('#SanctionDate1').datepicker({
		dateFormat: 'dd/mm/yy',
	   	changeYear : true,
    	changeMonth : true,
    	showOn: 'both',
        buttonImage: 'images/calendar.gif',
        buttonImageOnly: true,
	    maxDate : new Date()
	   	 
    });
	$('#yearOfPurchase').datepicker({
		dateFormat: 'yy',
		changeYear : true,
    	changeMonth : true,
    	showOn: 'both',
        buttonImage: 'images/calendar.gif',
        buttonImageOnly: true,
	    maxDate : new Date()
	   	 
    });
	
	  var delSettings ={
			  // define settings for Delete 
			  mtype: "post",	  
			  onclickSubmit: function (rp_ge, rowid) {		         
			             rp_ge.url = "deleteRepairveh.action?repToVehId="+rowid;
			             $("#repVehicleList").trigger("reloadGrid");
			             
			             $("#Failedtable").show();
			  }
		  };
	
	  $("#repVehicleList").jqGrid({
    	datatype:'xml',
 	  	mtype: 'Post', 		
		url:"geRepairVehDetails.action?action=fetchData",	  	   
		colNames:['Sanction No','Sanction Date','Vehicle Id ','Vehicle','Value','Controlling Office','Year Of Purchase','Value Of Repairs','Current BillAmt'],
		colModel:[
          	{ name: 'sanctionNo', index: 'sanctionNo',width : 100, align:'left',editable:true} ,
   			{ name: 'sanctionDate',index: 'sanctionDate',width : 114 ,formatter:'date',editable:true},
    		{ name: 'vehicleId', index: 'vehicleId',width : -10 ,align: 'left',editable:true,edittype:'select', editoptions:{dataUrl:'getVehicles.action'}} ,
    		{ name: 'vehicle',index: 'vehicle',width : 100 ,editable:false},
    		{ name: 'value',index: 'value',width : 58 ,align: 'left',editable:true},
    		{ name: 'controllingOfc', index: 'controllingOfc',width : 117,align: 'left',editable:true} ,
    		{ name: 'yearOfPurchase',index: 'yearOfPurchase',width : 138,editable:true},
    		{ name: 'valueOdRepairs', index: 'valueOdRepairs',width : 100 ,align: 'left',editable:true} ,
    		{ name: 'currBillAmt', index: 'currBillAmt',width : 150 ,align: 'left',editable:true} ,   			
 		 ],
 	   rowNum:10,
	   loadonce:false,
	   rownumbers:true,
 	   rowList:[5,10,20],
	   cellEdit: false, 
	   viewrecords:true,
	   caption:'Repairs Vehicle Details',		   
	   pager: '#pager',
	   width: 795,
	   height: 'auto',
	   shrinkToFit:false,
	   closeAfterAdd:true,
       closeAfterEdit:true,
       reloadAfterSubmit:true,
	    cellsubmit: 'clientArray',
	    ondblClickRow: function(rowid, ri, ci) {
	        var p = grid[0].p;
	        if (p.selrow !== rowid) {
	            // prevent the row from be unselected on double-click
	            // the implementation is for "multiselect:false" which we use,
	            // but one can easy modify the code for "multiselect:true"
	            grid.jqGrid('setSelection', rowid);
	        }					       
	        grid.jqGrid('editGridRow', rowid, editSettings);
	    }
	   //editurl: editSettings
	    
	 });	
 	 $("#repVehicleList").jqGrid('navGrid','#pager',{edit:false,add:false,del:true,search:true},{},{},delSettings,{closeAfterSearch:true})		 	 	
	 .navButtonAdd('#pager',{ caption:"Edit", buttonicon:"ui-icon-pencil",position:"first",title:'Edit',
	 	onClickButton:function(){	
	 		flag=1;
        	var rowid = $("#repVehicleList").jqGrid('getGridParam', 'selrow');	        	
        	if(rowid==null){
        		alert("Please select Row.");
        		return;
	        }
        	
        	var gridRow = $("#repVehicleList").getRowData(rowid);
        	
        	$("#rowIdVal").val(rowid);
        	$("#sanctionNo").val(gridRow.sanctionNo);
    		$("#SanctionDate1").val(gridRow.sanctionDate);
    		$("#vehicleId").val(gridRow.vehicleId);
    		$("#value").val(gridRow.value);
    		$("#controllingOfc").val(gridRow.controllingOfc);
    		$("#yearOfPurchase").val(gridRow.yearOfPurchase);
    		$("#valueOdRepairs").val(gridRow.valueOdRepairs);	
    		$("#currBillAmt").val(gridRow.currBillAmt);
	 	}
	});
 	
});*/