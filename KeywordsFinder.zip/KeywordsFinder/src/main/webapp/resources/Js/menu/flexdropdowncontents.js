//1st MENU Contents
/*
var flexmenu1=new ddlistmenu('flexmenu1', 'flexdropdownmenu') //var menuvar=new ddlistmenu('menuid', 'menuclass')
flexmenu1.addItem('#', 'Item 1a', '_new') //addItem(url, text, optionaltarget)
flexmenu1.addItem('#', 'Item 2a')
var subul3=flexmenu1.addItem('#', 'Item Folder 3a').addSubMenu() //create new 2nd level menu and assign it to new variable
	subul3.addItem('#', 'Sub Item 3.1a')
	subul3.addItem('#', 'Sub Item 3.2a')
	subul3.addItem('#', 'Sub Item 3.3a')
	subul3.addItem('#', 'Sub Item 3.4a')
flexmenu1.addItem('#', 'Item 4a')
var subul5=flexmenu1.addItem('#', 'Item Folder 5a').addSubMenu() //create new 2nd level menu and assign it to new variable
	subul5.addItem('#', 'Sub Item 5.1a')
	var subsubul5=subul5.addItem('#', 'Item Folder 5.2a').addSubMenu() //create new 3rd level menu and assign it to new variable
		subsubul5.addItem('#', 'Sub Item 5.2.1a')
		subsubul5.addItem('#', 'Sub Item 5.2.2a')
		subsubul5.addItem('#', 'Sub Item 5.2.3a')
		subsubul5.addItem('#', 'Sub Item 5.2.4a')
flexmenu1.addItem('#', 'Item 6a')
*/

//2nd MENU Contents
var flexmenu2=new ddlistmenu('flexmenu2', 'flexdropdownmenu');
flexmenu2.addItem('http://www.dynamicdrive.com', 'Dynamic Drive');
flexmenu2.addItem('http://www.cssdrive.com', 'CSS Drive');
flexmenu2.addItem('http://www.javascriptkit.com', 'JavaScript Kit');
flexmenu2.addItem('http://www.codingforums.com', 'Coding Forums');
flexmenu2.addItem('http://www.javascriptkit.com/domref/', 'DOM Reference');