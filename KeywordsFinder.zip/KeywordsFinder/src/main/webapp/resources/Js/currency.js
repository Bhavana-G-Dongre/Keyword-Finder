
/**
 *  To display amount in Indian Format (in lakhs with coma separator) for jqgrid
 *  Include globalize.js and globalize.cultures.js before calling this function
 *  Created by Shylesh Giri
 *  For More Info visit https://github.com/jquery/globalize
 */


$(document).ready(function(){	

	numberTemplate = {align: 'right', sorttype: 'number',
	
	        searchoptions: { sopt: ['eq', 'ne', 'lt', 'le', 'gt', 'ge', 'nu', 'nn', 'in', 'ni']},
	        formatoptions: { thousandsSeparator: ','} ,
	        formatter: function (v) {
	        		return Globalize.format(Number(v), "n");//n stands for number
	        },
	
	        unformat: function (v) {
	
	            return Globalize.parseFloat(v); // unformat values with coma
	
	        }
	},
	
	Globalize.culture("en-IN");//Specifying culture
});
