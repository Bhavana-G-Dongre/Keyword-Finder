var spacer = null; 
var curObj = null; 
function openIt(obj) 
{ 
	
	if ($.browser.msie) {

      if(spacer) return; 
      spacer = document.createElement("span"); 
      spacer.style.width = obj.offsetWidth; 
      spacer.style.height = obj.offsetHeight; 
      actualWidth=spacer.style.width;
      spacer.style.display = "none"; 
      obj.parentNode.insertBefore(spacer, obj); 
      obj.style.left = getAbsPos(obj, "Left"); 
      obj.style.top = getAbsPos(obj, "Top"); 
      obj.style.position = "absolute";
      obj.style.width = obj.scrollWidth; 
      finalWidth=obj.style.width;
if(actualWidth>finalWidth)
{
obj.style.width=actualWidth;
}
      obj.focus(); 
      spacer.style.display = "inline"; 
      curObj = obj; 

} 
}
function closeIt(width) 
{ 
	
	
	if ($.browser.msie) {
      if(spacer) 
      { 
            spacer.parentNode.removeChild(spacer); 
            spacer = null; 
      } 
      if(curObj) 
      { 
            curObj.style.width = width+"px"; 
            curObj.style.position = "static"; 
      } 
	}
} 
function getAbsPos(o,p){var i=0;while(o!=null){i+=o["offset"+p];o=o.offsetParent;}return i;}