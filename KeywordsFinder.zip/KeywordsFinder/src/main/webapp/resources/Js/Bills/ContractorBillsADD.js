
function PostRequest(strURL, flag) {// these function process the ajax request

	var xmlHttp = null;

	if (window.XMLHttpRequest) { // Mozilla, Safari, ...
		var xmlHttp = new XMLHttpRequest();
	} else if (window.ActiveXObject) { // IE
		var xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
	}

	xmlHttp.open('POST', strURL, true);

	xmlHttp.setRequestHeader('Content-Type',
			'application/x-www-form-urlencoded');
	xmlHttp.setRequestHeader("Connection", "close");
	xmlHttp.onreadystatechange = function() {

		if (xmlHttp.readyState == 4) {

			PostResponseText(xmlHttp.responseText, flag);

		}
	}
	xmlHttp.send(strURL);

}

function SetValueToSelectBox(List, id) {

	var sel = id;

	$('<option>').text("--Select--").val("-1").appendTo(sel);
	for ( var i = 0; i < List.length; i++) {
		var e = List[i];

		$('<option>').text(e).val(e).appendTo(sel);
	}
}
function SetValueToSelectBoxWithId(List, id) {

	var sel = id;

	$('<option>').text("--Select--").val("-1").appendTo(sel);
	for ( var i = 0; i < List.length; i++) 
	{
		$('<option>').text(List[i][0]).val(List[i][0]).appendTo(sel);
	}
}

function PostResponseText(ResponseText, flag) {
	if (flag == "Get Bill Type And Number") {
		$('#loader').css('visibility', 'hidden');
		SetValueOfBillTypeAndNumber(ResponseText);
	}
	else if (flag == "Get Bill Number") {
		SetValueOfBillNumber(ResponseText);
		$('#loader').css('visibility', 'hidden');
	}
	else if (flag == "Get Bill Details") {
		SetValueOfBillsDetails(ResponseText);
		$('#searchLoader').css('visibility', 'hidden');
	}

}
var LastBillNumber = 0;

function SetValueOfBillNumber(data)
{
	var JSONObject = jQuery.parseJSON(data);

	if (JSONObject.Message == "Found") 
	{
		
		$("select#billNo option").remove();
		SetValueToSelectBox(JSONObject.BillNoList, $('#billNo'));
		$("#BillsInformation").show(500);
		
		
		var iCurr = 0; 
		iCurr = JSONObject.CurrBillNo;
		if($("#billNo option[value='"+iCurr+"']").length > 0){
			$('select>option[value='+iCurr+']').css("background-color","yellow");
			$("#billNo").val(iCurr);
		}
	} else {
		alert(JSONObject.Message);
	}
}

function SetValueOfBillTypeAndNumber(data) {
	// alert(data);
	var JSONObject = jQuery.parseJSON(data);

	if (JSONObject.Message == "Found") {
		$("select#billType option").remove();
		SetValueToSelectBoxWithId(JSONObject.BillTypeList, $('#billType'));
		$("#BillsInformation").show(500);
	} else {
		alert(JSONObject.Message);
	}
}


function SetValueOfBillsDetails(data) {

	var JSONObject = jQuery.parseJSON(data);

	if (JSONObject.Message == "Found") {
		toCheckUndefined("PANID", JSONObject.PAN_ID);
		if(JSONObject.PAN_ID == 0)
			$("#PANID").val("");
		if (JSONObject.code == null || JSONObject.code == "") 
		{
			$("#ExecUnit").val("");
			alert("Executive code is not added for bill");
		}else
		{
			$("#ExecUnit").val(JSONObject.code + " - " + JSONObject.description);	
		}
		
		/*if(JSONObject.AMT_PYABLE == null || JSONObject.AMT_PYABLE == "")
		{
			alert("Please check Amount Payable before adding the bill");
			alertErrMsg();
			return;
		}*/
		if( JSONObject.BankCode == null || JSONObject.BankCode == " - ")
		{
			alert("Please check Bank Code before adding the bill");
			alertErrMsg();
			return;
		}
		if( JSONObject.CONTRACTOR_CODE == null || JSONObject.CONTRACTOR_CODE == "")
		{
			alert("Please check Contractor Code before adding the bill");
			alertErrMsg();
			return;
		}
		if( JSONObject.RecoverySame == "false" || JSONObject.RecoverySame == "")
		{
			alert("Please check Recoveries in PMS.   Bill has not been saved fully");
			alertErrMsg();
			return;
		}
		toCheckUndefined("AgreementNo", JSONObject.AGREEMENT_NO);
		toCheckUndefined("AgreementDate", JSONObject.AGREEMENT_DATE);
		toCheckUndefined("LOANO", JSONObject.LOA_NO);
		toCheckUndefined("LOADate", JSONObject.LOA_DATE);
		toCheckUndefined("ProjectCode", JSONObject.PROJ_CODE);
		toCheckUndefined("ProjectName", JSONObject.PROJ_NAME);
		toCheckUndefined("VoucherNo", JSONObject.VOC_NO);
		toCheckUndefined("VoucherDate", JSONObject.VOC_DT);
		toCheckUndefined("Payable", JSONObject.AMT_PYABLE);
		toCheckUndefined("BankCode", JSONObject.BankCode);
		toCheckUndefined("FileReferenceNo", JSONObject.FILE_REF);
		toCheckUndefined("Recovery", JSONObject.RECOVERY);
		toCheckUndefined("ContractorCode", JSONObject.CONTRACTOR_CODE);
		toCheckUndefined("ContractorName", JSONObject.CONTRACTOR_NAME);
		toCheckUndefined("AccountNo", JSONObject.ACCOUNTNO);
		toCheckUndefined("IFSCCode", JSONObject.IFSCCODE);

		var address = "Address -";
		if (JSONObject.ADRESS != undefined) {
			address = address + JSONObject.ADRESS;
		}
		if (JSONObject.CITY_NAME != undefined) {
			address = address + "\n City - " + JSONObject.CITY_NAME;
		}
		if (JSONObject.PINCODE != undefined) {
			address = address + "\n Pincode -" + JSONObject.PINCODE;
		}
		if (JSONObject.PHONE_NO != undefined) {
			address = address + "\n Phone - " + JSONObject.PHONE_NO;
		}
		// toCheckUndefined("ContractorDetails"," Address
		// -"+JSONObject.ADRESS+"\n City -
		// "+JSONObject.CITY_NAME+"\n Pincode -"+JSONObject.PINCODE+"\n Phone -
		// "+JSONObject.PHONE_NO);
		toCheckUndefined("ContractorDetails", address);
		toCheckUndefined("Executive_Id", JSONObject.EX_Id);
		// alert(JSONObject.EX_Id);
		toCheckUndefined("BANK_ID", JSONObject.BANK_ID);
		toCheckUndefined("AmountBilled", JSONObject.CURR_W_VAL);
		toCheckUndefined("BNK_RLY_IND", JSONObject.BNK_RLY_IND);

		$("#VC").attr("disabled", false);
		if(JSONObject.co6pass === undefined ||JSONObject.co6pass == null ||JSONObject.co6pass == "F")
		{
			$("#EditButton").hide();
		}
		else
		{
			$("#EditButton").show();
		}
		if (JSONObject.AlreadyExistsMessage == "Found") {
			$("#formSubmitButton").hide();
			$("#AlreadyExistsMessage").html("Bill Already registered ....");
			$("#CO6Date").attr("disabled", false);
			toCheckUndefined("CO6Date", JSONObject.Co6Date);
			toCheckUndefined("VC", JSONObject.VC);
			
			// alert(JSONObject.VC);
			$("#VC").attr("disabled", true);
			$("#EditButton").show();
			toCheckUndefined("FMCO6_ID", JSONObject.FMCO6_ID);

		} else {
			$("#formSubmitButton").show();
			$("#AlreadyExistsMessage").html("");
			$("#CO6Date").attr("disabled", false);
			// $("#CO6Date",$.format.date(new Date(), 'dd M yy'));
			// alert($.datepicker.formatDate('dd M yy', new Date()));
			/*toCheckUndefined("CO6Date", $.datepicker.formatDate('dd M yy',
					new Date()));*/
			toCheckUndefined("CO6Date", JSONObject.serverDate);
			// $("#EditButton").hide();
			toCheckUndefined("FMCO6_ID", "");

		}
		$("#BillsDetails").show(500);
		$("#ButtonTable").show(500);
	}
	else if (JSONObject.Message == "Error") {
		alert(JSONObject.ErrorMessage);
	}
	$("#EditFlag").val(false);

}

function ShowCo6DateEditOption() {
	$("#formSubmitButton").show();
	$("#CO6Date").attr("disabled", false);
	$("#VC").attr("disabled", false);
	$("#EditFlag").val(true);
}

function toCheckUndefined(id, value) {

	if (value === undefined || value == null) {
		$("#" + id).val("");
	} else {
		$("#" + id).val(value);
	}

	return value;
}