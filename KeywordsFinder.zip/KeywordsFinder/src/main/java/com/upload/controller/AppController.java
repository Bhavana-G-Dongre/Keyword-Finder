package com.upload.controller;

import java.awt.Desktop;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.validation.Valid;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.upload.model.FileBucket;
import com.upload.model.OodoData;
import com.upload.model.Read1;
import com.upload.model.Read2;
import com.upload.model.Read31;
import com.upload.model.Read41;
import com.upload.model.Read5;
import com.upload.model.UserDocument;
import com.upload.service.UserDocumentService;
import com.upload.util.FileValidator;

/***********************************************************************************
 * Controller  Class to handle all the actions.
 * 
 * @author Prasanta
 * @version 1.0
 ***********************************************************************************/

@Controller
@RequestMapping("/")
public class AppController {

	
	
	@Autowired
	UserDocumentService userDocumentService;
	
	@Autowired
	MessageSource messageSource;

	@Autowired
	FileValidator fileValidator;
	
	
	
	@InitBinder("fileBucket")
	protected void initBinder(WebDataBinder binder) {
	   binder.setValidator(fileValidator);
	}
	
	
	
	/**
	 The method will execute for the first time when the application runs.
	 */

	@RequestMapping(value="/", method= RequestMethod.GET)
	public ModelAndView loadJsp(ModelMap model1){
		
		
		
		FileBucket fileModel = new FileBucket();
		model1.addAttribute("fileBucket", fileModel);
		
		return new ModelAndView("/admin/managedocument",model1);
		
	}
	
	/**
	 The method will execute for the {adddocument GET} action .
	 */
	@RequestMapping(value = { "/adddocument" }, method = RequestMethod.GET)
	public String addDocuments( ModelMap model, HttpServletRequest req , HttpServletResponse res) {
		
		

		FileBucket fileModel = new FileBucket();
		model.addAttribute("fileBucket", fileModel);

		return "/admin/managedocument";
	}
	
	@RequestMapping(value = { "/showkeywords" }, method = RequestMethod.POST)
	public void showkeywords( ModelMap model, HttpServletRequest req , HttpServletResponse res) {
		
		
          List<OodoData> keywords=userDocumentService.keywords();
		  model.addAttribute("keywords", keywords);
          

	}

	@RequestMapping(value = { "/delete-user-{id}" }, method = RequestMethod.GET)
	public ModelAndView deleteKeywords(ModelMap model, @PathVariable long id, HttpServletRequest req , HttpServletResponse res) {
		
		try{
          userDocumentService.deleteKeywords(id);
          List<OodoData> keywords=userDocumentService.keywords();
		  model.addAttribute("keywords", keywords);

		  
		  ModelAndView mv = new ModelAndView("/admin/keywords" , model);
			mv.addObject("Msg","The keyword has been deleted.");
			return mv;
		}catch(Exception e){
			 ModelAndView mv = new ModelAndView("/admin/keywords" , model);
				mv.addObject("Msg","The keyword couldnot be deleted due to some problem.");
				return mv;
		}
	}

	

	
	/**
	 The method will execute for the {adddocument POST} action .
	 */
	@RequestMapping(value = { "/adddocument" }, method = RequestMethod.POST)
	public ModelAndView uploadDocument(@RequestParam("file") MultipartFile file,@RequestParam("file1") MultipartFile file1,@Valid FileBucket fileBucket,BindingResult result,  ModelMap model,HttpServletRequest request,
	        HttpServletResponse response) throws ServletException,IOException{
		
		
		userDocumentService.truncateTbl();
		
		BufferedReader br = null;
		FileReader fr = null;
		

		
		FileBucket fileModel = new FileBucket();
		model.addAttribute("fileBucket", fileModel);
		 try{
		
	/*if (result.hasErrors()) {
			System.out.println("validation errors");
			
			
			ModelAndView mv = new ModelAndView("/admin/managedocument" , model);
			mv.addObject("Msg","Your File size is too large, Please upload files with in 5MB.");
		    return mv;
		} else  {*/
		
			
			
			
		    System.out.println("Fetching file");
		    
		    System.out.println("Fetching file");
			
		  //  String radioType=request.getParameter("new");
		   // System.out.println("oooooooooooooooo"+radioType);
			
			// creating folder for each applicant
			File theDir = new File("C:/KeywordsFinder/");

			// if the directory does not exist, create it
			if (!theDir.exists()) {
			    boolean result1 = false;

			   
			        theDir.mkdirs();
			        result1 = true;
			          
			    if(result1) {    
			        System.out.println("DIR created");  
			    }
			}
			String destPath="C:/KeywordsFinder/"+"/"+file.getOriginalFilename().replace(" ", "_");
			
			String destPath1="C:/KeywordsFinder/"+"/"+file1.getOriginalFilename().replace(" ", "_");
			
			
			
			InputStream is = new ByteArrayInputStream(file.getBytes());
			FileOutputStream fos = new FileOutputStream(theDir+"/"+file.getOriginalFilename().replace(" ", "_"));
			int b = 0;
			while ((b = is.read()) != -1)
				fos.write(b); 
			is.close();
			fos.close();
			
			InputStream is1 = new ByteArrayInputStream(file1.getBytes());
			FileOutputStream fos1 = new FileOutputStream(theDir+"/"+file1.getOriginalFilename().replace(" ", "_"));
			int b1 = 0;
			while ((b1 = is1.read()) != -1)
				fos1.write(b1); 
			is1.close();
			fos1.close();
			
			String path=destPath+"";
			String path1=destPath1+"";
			saveDocumentNew(file,file1,path,path1);
		    
		    List<OodoData> rs= new ArrayList<OodoData>();
		    rs=userDocumentService.fetchDataForExcel();
		    
		    String FILENAME1=path;
		    String FILENAME2=path1; 
		   /* String FILENAME1 = "D:\\IMPSL-text\\IMSPL_300_16-17_Arrow Pc Network.txt";
	    	String FILENAME2 = "D:\\IMPSL-text\\IMSPL_301_16-17_Team Computers - Copy.txt";*/
	    	//**********************************************//
		    try {
		    	String dbname="keywordsfinder";
				String driver="com.mysql.jdbc.Driver";
				Class.forName(driver).newInstance();
				Connection con=null;
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/"+dbname,"root","");
				Statement stmt=con.createStatement();
		    
		    	
				Class.forName(driver).newInstance();
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/"+dbname,"root","");
				
				
		    	Read1 obj=new Read1();
				BufferedReader br1=new BufferedReader(new InputStreamReader(System.in));
				fr = new FileReader(FILENAME1);
				br = new BufferedReader(fr);

				String sCurrentLine;

				br = new BufferedReader(new FileReader(FILENAME1));
				int k=0;
				while ((sCurrentLine = br.readLine()) != null) {
					k++;
					sCurrentLine=sCurrentLine.trim();
					String[] s=sCurrentLine.split("\\s+");
					//System.out.println(sCurrentLine);
					for(int j=0;j<s.length;j++)
					{
					obj.setName(s[j]);
					obj.setLine(k);
					obj.setId1(j);
					userDocumentService.saveFileOne(obj);
					
					}
				}
				

			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
				
			try {
				String dbname="keywordsfinder";
				String driver="com.mysql.jdbc.Driver";
				Class.forName(driver).newInstance();
				Connection con=null;
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/"+dbname,"root","");
				Statement stmt=con.createStatement();
			
				Class.forName(driver).newInstance();
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/"+dbname,"root","");
				
				BufferedReader br1=new BufferedReader(new InputStreamReader(System.in));

				String sCurrentLine;
				
				br = new BufferedReader(new FileReader(FILENAME2));
				Read2 obj=new Read2();
				int k=0;
				while ((sCurrentLine = br.readLine()) != null) {
					k=k+1;
					sCurrentLine=sCurrentLine.trim().replaceAll("[\n]{2,}", " ");
					String[] s=sCurrentLine.split("\\s+");
					
					for(int j=0;j<s.length;j++)
					{
						obj.setName(s[j]);
						obj.setLine(k);
						obj.setId1(j);
						userDocumentService.saveFileTwo(obj);
					
					}
				}

			} catch (Exception e)
			{
				e.printStackTrace();
			}
			
			try {
			
				String dbname="keywordsfinder";
				String driver="com.mysql.jdbc.Driver";
				Class.forName(driver).newInstance();
				Connection con=null;
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/"+dbname,"root","");
				Statement stmt=con.createStatement();
				ResultSet rs1=stmt.executeQuery("SELECT DISTINCT GROUP_CONCAT(name  order by id1 SEPARATOR ' ')as n1, line, id FROM read1 GROUP BY line");
				Read31 obj=new Read31();
				String[] s1=new String[100];
				int i1=0;
				try{
				while(rs1.next())
				{
					String n=rs1.getString(1);
					System.out.println("***************&&&&&&&&&&&&&&&&&&&");
					System.out.println(n);
					s1[i1]=n;
					if(s1[i1]!=null)
					{
						int line=rs1.getInt(2);
						int idd=rs1.getInt(3);
						obj.setName(s1[i1]);
						obj.setLine(line);
						obj.setId1(idd);
						userDocumentService.saveMatchingSubKeywords(obj);
					
					}
					i1++;
				}
			
				for(int k=0;k<s1.length;k++)
					System.out.println(s1[k]+"\n");
				}
				catch(Exception e)
				{}
				String[] s2=new String[100];
				try{
				String dbname1="keywordsfinder";
				String driver1="com.mysql.jdbc.Driver";
				Class.forName(driver1).newInstance();
				Connection con1=null;
				con1=DriverManager.getConnection("jdbc:mysql://localhost:3306/"+dbname1,"root","");
				Statement stmt1=con1.createStatement();
				
				ResultSet rs2=stmt1.executeQuery("SELECT DISTINCT GROUP_CONCAT(name  order by id1 SEPARATOR ' ')as n1, line, id FROM read2 GROUP BY line");
				
				int i2=0;
				Read41 obj1=new Read41();
				
						
				while(rs2.next())
				{
					String n=rs2.getString(1);
					System.out.println("&&&&&&&&&&&&&&&&&&&");
					System.out.println(n);
					s2[i2]=n;
					if(s2[i2]!=null)
					{
					int line=rs2.getInt(2);
					int idd=rs2.getInt(3);
					obj1.setName(s2[i2]);
					obj1.setLine(line);
					obj1.setId1(idd);
					userDocumentService.saveMatchingSubKeywords1(obj1);
					
					}
					i2++;
				}
				for(int k=0;k<s2.length;k++)
					
					System.out.println(s2[k]+"\n");
				}
				
				catch(Exception e)
				{
					e.printStackTrace();
				}
			boolean k;
			String z="";
			String[] y=new String[100];
			String[] x=new String[100];
			int z2=0;
			Read5 obj2=new Read5();
			for(int m=0;m<s1.length;m++)
			{
				for(int n=0;n<s2.length;n++)
				{
					z="";
					try{
					if((x=s1[m].split("\\s+"))!=null&&(y=s2[n].split("\\s+"))!=null)
					{
					for(int x1=0,y1=0;x1<x.length&&y1<y.length;x1++,y1++)
					{
						   if(x[x1].equals(y[y1])&&x[x1]!="\n"){
							   
							   //System.out.print(x[x1]+" ");
							   z=z+" "+x[x1];   
						   }
					}
					
					System.out.print(z);
					//ps.setString(1,z);
					obj2.setData(z);
					userDocumentService.saveMatchingKeywords(obj2);
					}
					}
					catch(Exception e)
					{
						
					}
					z2++;
				}
			
			
			}
	    	//************************************************************//
		
	    	String dbname2="keywordsfinder";
			String driver2="com.mysql.jdbc.Driver";
			Class.forName(driver2).newInstance();
			Connection con2=null;
			con2=DriverManager.getConnection("jdbc:mysql://localhost:3306/"+dbname2,"root","");
			Statement stmt2=con2.createStatement();
			ResultSet rs3=stmt2.executeQuery("SELECT distinct * from read5 where data REGEXP '[A-Za-z0-9:]'");
			String[] s3=new String[1000];
			int i3=0;
			while(rs3.next())
			{
				String n=rs3.getString(2);
				System.out.println("ppppppppppppppppppp");
				System.out.println(n);
				s3[i3]=n;
				i3++;
			}
			OodoData o1=new OodoData();
			int kk=0;
			for(int i=0;i<s3.length&&s3[i]!=null;i++){
				kk=kk+1;
				System.out.println(s3[i]);
				o1.setC1(s3[i]);
				
				userDocumentService.saveOodoData(o1);
			}
			
				
		}
			
			
		catch(Exception e)
		{
			System.out.println(e);
		}
			
		    
		 
			
		
			/*File theDir = new File("C:/KeywordsFinder/");

			
			if (!theDir.exists()) {
			    boolean result1 = false;

			   
			        theDir.mkdirs();
			        result1 = true;
			          
			    if(result1) {    
			        System.out.println("DIR created");  
			    }
			}
			String destPath="C:/KeywordsFinder/"+"/"+file.getOriginalFilename().replace(" ", "_");
			
			String destPath1="C:/KeywordsFinder/"+"/"+file1.getOriginalFilename().replace(" ", "_");
			
			
			
			InputStream is = new ByteArrayInputStream(file.getBytes());
			FileOutputStream fos = new FileOutputStream(theDir+"/"+file.getOriginalFilename().replace(" ", "_"));
			int b = 0;
			while ((b = is.read()) != -1)
				fos.write(b); 
			is.close();
			fos.close();
			
			InputStream is1 = new ByteArrayInputStream(file1.getBytes());
			FileOutputStream fos1 = new FileOutputStream(theDir+"/"+file1.getOriginalFilename().replace(" ", "_"));
			int b1 = 0;
			while ((b1 = is1.read()) != -1)
				fos1.write(b1); 
			is1.close();
			fos1.close();
			
			String path=destPath+"";
			String path1=destPath1+"";
			
			saveDocument(file, path);
			
			
			saveDocumentNew(file, file1, path, path1);	*/
				
			List<OodoData> keywords=userDocumentService.keywords();
			  model.addAttribute("keywords", keywords);	
			
			ModelAndView mv = new ModelAndView("/admin/keywords" , model);
			mv.addObject("Msg","Your Documents has uploaded Sucessfully.");
			return mv;
			
			
			
		 
		
		 } 
	
	//*********************************************************************//
		    catch(Exception see){

		    	see.printStackTrace();
		    	ModelAndView mv = new ModelAndView("/admin/managedocument" , model);
				mv.addObject("Msg","Your Document has not uploaded due to some problem , Please try again.");
			    return mv;
		    }
		
		
	}
	
	//*********************************************************************//
	
	
	/**
	 The method will execute for saving the first Document .
	 */
	private void saveDocument(MultipartFile file, String path) throws IOException{
		
		UserDocument document = new UserDocument();
		
		
		document.setName1(file.getOriginalFilename());
		document.setType1(file.getContentType());
		document.setPath1(path);
		userDocumentService.saveDocument(document);
	}
	
	/**
	 The method will execute for saving the Second Document .
	 */
	
    private void saveDocumentNew(MultipartFile file,MultipartFile file1, String path, String path1) throws IOException{
		
		UserDocument document = new UserDocument();
		
		
		
		document.setName1(file.getOriginalFilename());
		document.setType1(file.getContentType());
		document.setPath1(path);
		document.setName2(file1.getOriginalFilename());
		document.setType2(file1.getContentType());
		document.setPath2(path1);
		userDocumentService.saveDocument(document);
	}
	


    /**
	 The method will execute for comparing the two documents and getting the keywords .
	 */
  
    private void comparingTwoFiles(String path, String path1) throws IOException{
	
	
}

    /**
	 The method will execute for  getting  key and value pairs .
	 */


    private void gettingKeyValue(String path) throws IOException{
    	
    	
    	
    	
    }
    @RequestMapping("/exportExeclForToday")
    public void exportSysDateData() throws ClassNotFoundException, SQLException{
    	
    	
    	long millis=System.currentTimeMillis();  
        java.sql.Date date=new java.sql.Date(millis);
    	List<OodoData> rs= new ArrayList<OodoData>();
        
        
    	try {
    		  
    	   /* Class.forName("com.mysql.jdbc.Driver");
    	    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/keywordsfinder", "root", "root123");
    	    Statement st = con.createStatement();
    	    ResultSet rs = st.executeQuery("Select * from oodo_data where sys_date="+date.toString());*/
    	   
    		/*rs=userDocumentService.fetchDataForExcel(date);
    		HSSFWorkbook workbook = new HSSFWorkbook();
    	    HSSFSheet sheet = workbook.createSheet("lawix10");
    	    HSSFRow rowhead = sheet.createRow((short) 0);
    	    rowhead.createCell((short) 0).setCellValue("Purchase order no.umber");
    	    rowhead.createCell((short) 1).setCellValue("Purchase Order Date(Dated)");
    	    rowhead.createCell((short) 2).setCellValue("Reseller/Dealer Information(name / Company Name) ");
    	    rowhead.createCell((short) 3).setCellValue("Reseller/Dealer Information(Street1)");
    	    rowhead.createCell((short) 4).setCellValue("Reseller/Dealer (Street2)");
    	    rowhead.createCell((short) 5).setCellValue("Reseller/Dealer (City)");
    	    rowhead.createCell((short) 6).setCellValue("Reseller/Dealer (State)");
    	    rowhead.createCell((short) 7).setCellValue("Reseller/Dealer (Contact Person)");
    	    rowhead.createCell((short) 8).setCellValue("Reseller/Dealer (Email_id)");
    	    rowhead.createCell((short) 9).setCellValue("Reseller/Dealer (Phone/Mobile number)");
    	    rowhead.createCell((short) 10).setCellValue("Reseller/Dealer (Pin Code)");
    	    rowhead.createCell((short) 11).setCellValue("Reseller/Dealer (Country)");
    	    rowhead.createCell((short) 12).setCellValue("End-customer(Name /company Name)");
    	    rowhead.createCell((short) 13).setCellValue("End-customer(Street1)");
    	    rowhead.createCell((short) 14).setCellValue("End-customer(Street2)");
    	    rowhead.createCell((short) 15).setCellValue("End-customer(City)");
    	    rowhead.createCell((short) 16).setCellValue("End-customer(State)");
    	    rowhead.createCell((short) 17).setCellValue("End-customer(Country)");
    	    rowhead.createCell((short) 18).setCellValue("End-customer(Contact person)");
    	    rowhead.createCell((short) 19).setCellValue("End-customer(Contact person email id)");
    	    rowhead.createCell((short) 20).setCellValue("End-customer(Phone/Mobile)");
    	    rowhead.createCell((short) 21).setCellValue("End-customer(Zip)");
    	    rowhead.createCell((short) 22).setCellValue("Acct# or Red Hat Network Login (if known):");
    	    rowhead.createCell((short) 23).setCellValue("Contract Number");
    	    rowhead.createCell((short) 24).setCellValue("Reseller P.O.");
    	    rowhead.createCell((short) 25).setCellValue("Contract Start Date");
    	    rowhead.createCell((short) 26).setCellValue("Reseller Account");
    	    rowhead.createCell((short) 27).setCellValue("SKU#");
    	    rowhead.createCell((short) 28).setCellValue("Product Description");
    	    rowhead.createCell((short) 29).setCellValue("Unit Price");
    	    rowhead.createCell((short) 30).setCellValue("Quantity");
    	    rowhead.createCell((short) 31).setCellValue("Cst");
    	    rowhead.createCell((short) 32).setCellValue("Sevice tax");
    	    rowhead.createCell((short) 33).setCellValue("Sbc Tax");
    	    rowhead.createCell((short) 34).setCellValue("Kkc Tax");
    	    rowhead.createCell((short) 35).setCellValue("Vendor");
    	    rowhead.createCell((short) 36).setCellValue("Billing & Shipping Address");
    	    rowhead.createCell((short) 37).setCellValue("Payment Terms");
    	    rowhead.createCell((short) 38).setCellValue("SFDC ID");*/
    	    //rowhead.createCell((short) 38).setCellValue("asdf");
    	    //rowhead.createCell((short) 39).setCellValue("asdf");
    	    int i = 1;
    	   /* while (rs.next()){
    	        HSSFRow row = sheet.createRow((short) i);
    	        row.createCell((short) 0).setCellValue(Long.toString(rs.getLong("id")));
    	        row.createCell((short) 1).setCellValue(rs.getString("c1"));
    	        row.createCell((short) 2).setCellValue(rs.getString("c2"));
    	        i++;
    	    }*/
    	    
    	    for(int p=0;p<rs.size();p++){
    	    	 /*HSSFRow row = sheet.createRow((short) i);
    	    	 row.createCell((short) 0).setCellValue(rs.get(p).getC1());
    	    	 row.createCell((short) 1).setCellValue(rs.get(p).getC2());
    	    	 row.createCell((short) 2).setCellValue(rs.get(p).getC4());
    	    	 row.createCell((short) 3).setCellValue(rs.get(p).getC6());
    	    	 row.createCell((short) 4).setCellValue(rs.get(p).getC8());
    	    	 row.createCell((short) 5).setCellValue(rs.get(p).getC9());
    	    	 row.createCell((short) 6).setCellValue(rs.get(p).getC13());
    	    	 row.createCell((short) 7).setCellValue(rs.get(p).getC17());
    	    	 row.createCell((short) 8).setCellValue(rs.get(p).getC20());
    	    	 row.createCell((short) 9).setCellValue(rs.get(p).getC21());
    	    	 row.createCell((short) 10).setCellValue(rs.get(p).getC14());
    	    	 row.createCell((short) 11).setCellValue(rs.get(p).getC12());
    	    	 row.createCell((short) 12).setCellValue(rs.get(p).getC3());
    	    	 row.createCell((short) 13).setCellValue(rs.get(p).getC5());
    	    	 row.createCell((short) 14).setCellValue(rs.get(p).getC7());
    	    	 row.createCell((short) 15).setCellValue(rs.get(p).getC11());
    	    	 row.createCell((short) 16).setCellValue(rs.get(p).getC15());
    	    	 row.createCell((short) 17).setCellValue(rs.get(p).getC10());
    	    	 row.createCell((short) 18).setCellValue(rs.get(p).getC18());
    	    	 row.createCell((short) 19).setCellValue(rs.get(p).getC19());
    	    	 row.createCell((short) 20).setCellValue(rs.get(p).getC22());
    	    	 row.createCell((short) 21).setCellValue(rs.get(p).getC16());
    	    	 row.createCell((short) 22).setCellValue(rs.get(p).getC27());
    	    	 row.createCell((short) 23).setCellValue(rs.get(p).getC28());
    	    	 row.createCell((short) 24).setCellValue(rs.get(p).getC29());
    	    	 row.createCell((short) 25).setCellValue(rs.get(p).getC25());
    	    	 row.createCell((short) 26).setCellValue(rs.get(p).getC26());
    	    	 row.createCell((short) 27).setCellValue(rs.get(p).getC30());
    	    	 row.createCell((short) 28).setCellValue(rs.get(p).getC31());
    	    	 row.createCell((short) 29).setCellValue(rs.get(p).getC32());
    	    	 row.createCell((short) 30).setCellValue(rs.get(p).getC33());
    	    	 row.createCell((short) 31).setCellValue(rs.get(p).getC34());
    	    	 row.createCell((short) 32).setCellValue(rs.get(p).getC35());
    	    	 row.createCell((short) 33).setCellValue(rs.get(p).getC36());
    	    	 row.createCell((short) 34).setCellValue(rs.get(p).getC37());
    	    	 row.createCell((short) 35).setCellValue(rs.get(p).getC23());
    	    	 row.createCell((short) 36).setCellValue(rs.get(p).getC24());
    	    	 row.createCell((short) 37).setCellValue(rs.get(p).getC38());
    	    	 row.createCell((short) 38).setCellValue(rs.get(p).getC39());*/
    	    	 
    	    	 i++;
    	    }
    	   
    	    
    	   
    	    
    	    String yemi = "D:\\docs\\Xls\\"+date.toString()+".xls";
    	    FileOutputStream fileOut = new FileOutputStream(yemi);
    	    //workbook.write(fileOut);
    	    fileOut.close();
    	    } catch (FileNotFoundException e1) {
    	        e1.printStackTrace();
    	    } catch (IOException e1) {
    	        e1.printStackTrace();
    	    }
    	try {
			Desktop.getDesktop().open(new File("D:\\docs\\Xls\\"+date.toString()+".xls"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	
}



 class Mymethod {
	 String s2="",s5="",s21="",s51="";
		String s11="";
	public  void  method1(String s1i)
	{
		
		s2="";s5="";s21="";s51="";
		System.out.println(s1i);
		
		if(s1i.contains(":"))
		{
			String[] s3=s1i.split(":");
			if(s3[0].contains("&"))
			{
				StringBuilder sb= new StringBuilder();
				String mainString=s1i;
				String[] fst=mainString.split(":");
				String [] secnd= fst[1].split("\t");
				//System.out.println(secnd[1]+" "+secnd[2]+"  Part 1");
				try{
				s2=secnd[1];
				}
				catch(Exception e)
				{
					s2="";
				}
				try{
				s5=secnd[2];
				}
				catch(Exception e)
				{
					s5="";
				}
				for(int i1=3;i1<secnd.length;i1++){
					sb.append(secnd[i1]);
					
					sb.append(" ");
				}
				System.out.println(sb.toString()+" Part 2");
				String[] xx=sb.toString().split("\\s{2}+");
				try{
				System.out.println(xx[0]+"hj");
				s21=xx[0];
				System.out.println(xx[1]);
				s51=xx[1];
				}
				catch(Exception e)
				{}
		      }

			else
			{
				System.out.println(s3[1]);
				String[] s4=s3[1].trim().split("\\s{2,}");
				s2=s4[0];
				s11=s3[0];
				try{
					System.out.println(s2);
					System.out.println("hi");
					System.out.println(s4[1]);
					s5=s4[1];	
					}
				catch(Exception e)
				{}
			}
		}
		else{
			
			
			
	}
		}
}


