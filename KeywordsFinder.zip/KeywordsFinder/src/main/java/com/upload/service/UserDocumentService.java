package com.upload.service;

import java.util.Date;
import java.util.List;

import com.upload.model.OodoData;
import com.upload.model.Read1;
import com.upload.model.Read2;
import com.upload.model.Read31;
import com.upload.model.Read41;
import com.upload.model.Read5;
import com.upload.model.UserDocument;

public interface UserDocumentService {


	
	
	void saveDocument(UserDocument document);
	
	void saveFileOne(Read1 read1);
	
	void saveFileTwo(Read2 read2);
	
	void saveMatchingKeywords(Read5 read5);
	
	void saveMatchingSubKeywords(Read31 read31);
	
	void saveOodoData(OodoData obj);
	
	public List<OodoData> fetchDataForExcel();
	
	public List<OodoData> keywords();
	
	public void deleteKeywords(long id);

	void saveMatchingSubKeywords1(Read41 read41);
	
	public void truncateTbl();
	
}
