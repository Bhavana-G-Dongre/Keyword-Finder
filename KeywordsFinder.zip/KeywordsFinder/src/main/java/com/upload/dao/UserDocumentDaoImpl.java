package com.upload.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.upload.model.OodoData;
import com.upload.model.Read1;
import com.upload.model.Read2;
import com.upload.model.Read31;
import com.upload.model.Read41;
import com.upload.model.Read5;
import com.upload.model.UserDocument;

@Repository("userDocumentDao")
public class UserDocumentDaoImpl  implements UserDocumentDao{

	
	@Autowired
	private SessionFactory sessionFactory;
	

	public void save(UserDocument document) {
		sessionFactory.getCurrentSession().save(document);
	}


	public void saveFileOne(Read1 read1) {
		sessionFactory.getCurrentSession().save(read1);
	}

	
	public void saveFileTwo(Read2 read2) {
		sessionFactory.getCurrentSession().save(read2);
	}

	

	public void saveMatchingKeywords(Read5 read5) {
		sessionFactory.getCurrentSession().save(read5);		
	}


	public void saveMatchingSubKeywords(Read31 read31) {
		sessionFactory.getCurrentSession().save(read31);	
	}
	
	public void saveMatchingSubKeywords1(Read41 read41) {
		sessionFactory.getCurrentSession().save(read41);	
	}


	public void saveOodoData(OodoData obj) {
		
		sessionFactory.getCurrentSession().save(obj);
	}


	

	public List<OodoData> fetchDataForExcel() {
		return sessionFactory.openSession().createQuery("from OodoData").list();
	}


	public List<OodoData> keywords() {
		return sessionFactory.openSession().createQuery("from OodoData").list();
	}


	public void deletekeywords(long id) {
        sessionFactory.openSession().createSQLQuery("delete from key_words where id ="+id+";").executeUpdate();		
	}


	public void truncateTbl() {
		
		sessionFactory.openSession().createSQLQuery("truncate table read1").executeUpdate();
		sessionFactory.openSession().createSQLQuery("truncate table read2").executeUpdate();
		sessionFactory.openSession().createSQLQuery("truncate table read31").executeUpdate() ;
		sessionFactory.openSession().createSQLQuery("truncate table read41").executeUpdate();
		sessionFactory.openSession().createSQLQuery("truncate table read5").executeUpdate();
		sessionFactory.openSession().createSQLQuery("truncate table key_words").executeUpdate();
	}

	
	

}
