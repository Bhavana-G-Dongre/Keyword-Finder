

public class TestString {

	public static void main(String[] args) {

		StringBuilder sb= new StringBuilder();
		String mainString="Phone & Fax #*  :			965078515";
		String[] fst=mainString.split(":");
		String [] secnd= fst[1].split("\t");
		System.out.println(secnd[1]+" "+secnd[2]+"  Part 1");
		for(int i=3;i<secnd.length;i++){
			sb.append(secnd[i]);
			sb.append(" ");
		}
		
        System.out.println(sb.toString()+" Part 2");
      }
	}

